// task02part2
class BankAccount {
    public double getInterestRate() {
        return 0.05; 
    }
}
class SavingsAccount extends BankAccount {
    @Override
    public double getInterestRate() {
        return 0.10; 
    }
}
public class Task02part2{
    public static void main(String[] args) {
        BankAccount basicAccount = new BankAccount();
        BankAccount savingsAccount = new SavingsAccount(); 

        System.out.println("BankAccount Interest Rate: " + (basicAccount.getInterestRate() * 100) + "%");
        System.out.println("SavingsAccount Interest Rate: " + (savingsAccount.getInterestRate() * 100) + "%");
    }
}
