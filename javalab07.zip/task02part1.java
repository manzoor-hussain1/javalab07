//task02part01
class Employee {
    public double calculateSalary() {
        return 30000.0; // Base salary
    }
}
class Manager extends Employee {
    @Override
    public double calculateSalary() {
        return 30000.0 + 20000.0; // Base + bonus
    }
}
class Worker extends Employee {
    @Override
    public double calculateSalary() {
        return 30000.0 + (100 * 160); // Base + hourly (e.g., 100/hr * 160 hrs)
    }
}
public class Task02part1 {
    public static void main(String[] args) {
        Employee emp = new Employee();
        Employee mgr = new Manager();  // Polymorphism
        Employee wrk = new Worker();   // Polymorphism

        System.out.println("Employee Salary: $" + emp.calculateSalary());
        System.out.println("Manager Salary: $" + mgr.calculateSalary());
        System.out.println("Worker Salary: $" + wrk.calculateSalary());
    }
}
