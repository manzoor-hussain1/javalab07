//task04
package myfirstgui;
public class task04{
    private int clickCount = 0;
    public MainUI() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    private void initComponents() {
        clickButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("My First GUI");

        clickButton.setText("Click Me!");
        clickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clickButtonActionPerformed(evt);
            }
        });

        getContentPane().setLayout(new java.awt.FlowLayout());
        getContentPane().add(clickButton);
        pack();
    }

    private void clickButtonActionPerformed(java.awt.event.ActionEvent evt) {
        clickCount++;
        getContentPane().setBackground(java.awt.Color.YELLOW);
        clickButton.setText("Clicked " + clickCount + " time(s)");
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new MainUI().setVisible(true);
        });
    }
    private javax.swing.JButton clickButton;
}
