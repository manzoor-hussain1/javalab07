//task03
class Animal {
    protected String name;
    protected int age;
    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void displayInfo() {
        System.out.println("Animal Name: " + name);
        System.out.println("Animal Age: " + age);
    }
}
class Dog extends Animal {
    public Dog(String name, int age) {
        super(name, age); // Call to superclass constructor
    }
}
class Cat extends Animal {
    public Cat(String name, int age) {
        super(name, age); // Call to superclass constructor
    }
}
public class task03 {
    public static void main(String[] args) {
        Dog dog = new Dog("Buddy", 4);
        Cat cat = new Cat("Whiskers", 3);

        System.out.println("Dog Info:");
        dog.displayInfo();

        System.out.println("\nCat Info:");
        cat.displayInfo();
    }
}
