//task01
class Message {
    protected String text;
    public Message() {
        this.text = "";
    }
    public void setText(String text) {
        this.text = text;
    }
    public String getText() {
        return this.text;
    }
    public String toString() {
        return text;
    }
}
class SMS extends Message {
    private String recipientContactNo;

    public SMS(String recipientContactNo, String text) {
        this.recipientContactNo = recipientContactNo;
        this.text = text;
    }

    public String getRecipientContactNo() {
        return recipientContactNo;
    }

    public void setRecipientContactNo(String recipientContactNo) {
        this.recipientContactNo = recipientContactNo;
    }

    @Override
    public String toString() {
        return "SMS to: " + recipientContactNo + "\nMessage: " + text;
    }
}
class Email extends Message {
    private String sender;
    private String receiver;
    private String subject;

    public Email(String sender, String receiver, String subject, String text) {
        this.sender = sender;
        this.receiver = receiver;
        this.subject = subject;
        this.text = text;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public String getSubject() {
        return subject;
    }

    @Override
    public String toString() {
        return "From: " + sender + "\nTo: " + receiver + "\nSubject: " + subject + "\nMessage: " + text;
    }
}

// Utility class with keyword check
class MessageUtils {
    public static boolean containsKeyword(Message m, String keyword) {
        if (m.getText() != null) {
            return m.getText().toLowerCase().contains(keyword.toLowerCase());
        }
        return false;
    }
}
public class task01{
    public static void main(String[] args) {
        SMS sms = new SMS("9876543210", "Hello! Your OTP is 123456.");
        Email email = new Email("admin@example.com", "user@example.com", "Welcome", "Thank you for signing up!");
        System.out.println("SMS Details:\n" + sms);
        System.out.println("\nEmail Details:\n" + email);
        String keyword = "OTP";
        System.out.println("\nKeyword Check:");
        System.out.println("SMS contains '" + keyword + "': " + MessageUtils.containsKeyword(sms, keyword));
        System.out.println("Email contains '" + keyword + "': " + MessageUtils.containsKeyword(email, keyword));
    }
}
